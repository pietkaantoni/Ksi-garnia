﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

using ProjektPO.Interfaces;
using static KsiegarniaApp.Program;

namespace ProjektPO.Classes
{
    internal class Ksiegarnia : IInfo
    {
        //pole i właściwość, sprawiające, że nie ma potrzeby tworzyć Obiektu klasy Ksiegarnia
        private static Ksiegarnia _instance;
        public static Ksiegarnia Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Ksiegarnia();
                }
                return _instance;
            }
        }

        //Lista książek przechowywanych w księgarnii
        public List<Book> Books { get; set; } = new List<Book>();

        //Metoda, pokazująca wszystkie książki oraz ich przechowywaną ilość w księgarnii
        public string DisplayInfo()
        {
            string output = $"\nKsięgarnia, tytuły posiadanych książek:";
            foreach (Book book in Books)
            {
                output += $"\n - \"{book.Tytul}\", autor: {book.Autor}, cena: {book.Cena:C}, liczba książek w księgarni: {book.Ilosc}";
            }
            return output;
        }

        private Ksiegarnia()
        {
            // Inicjalizacja przykładowych książek w pamięci
            Books.Add(new Book("Wiedźmin", "Andrzej Sapkowski", 29.99d, 100));
            Books.Add(new Book("Lalka", "Bolesław Prus", 39.98d, 28));
            Books.Add(new Book("Pan Tadeusz", "Adam Mickiewicz", 12.50d, 13));
        }
    }
}
