﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

using ProjektPO.Interfaces;
using static KsiegarniaApp.Program;
using ProjektPO.Enums;

namespace ProjektPO.Classes
{
    // Delegat i Event
    public delegate void PowiadomienieEventHandler(object sender, string message);
    internal class Osoba : IInfo
    {
        private string _username;   //nazwa użytkownika
        public string Username
        {
            get { return _username; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Wartość nie może być pusta");
                _username = value;
            }
        }
        public Role Roles;  //Rola, którą ma każda osoba w programie

        //zdarzenie
        public event Action<object, string> Powiadomienie;
        protected virtual void OnPowiadomienie(string message)
        {
            Powiadomienie?.Invoke(this, message);
        }

        //konstruktor Osoby
        public Osoba(string username)
        {
            Username = username;
        }

        //Metoda, pokazujące szczegóły o osobie
        public string DisplayInfo()
        {
            string output = $"\nNazwa użytkownika: {Username}, posiadana rola: {Roles}";
            return output;
        }
    }
}
