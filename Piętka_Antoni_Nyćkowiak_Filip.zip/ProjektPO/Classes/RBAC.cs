﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static KsiegarniaApp.Program;
using ProjektPO.Enums;

namespace ProjektPO.Classes
{
    internal class RBAC
    {
        //Słownik, który ma zapisane, jakie są pozwolenia danej Roli
        private readonly Dictionary<Role, List<Permission>> _rolePermissions;
        public RBAC()
        {
            _rolePermissions = new Dictionary<Role, List<Permission>>
                    {
                        { Role.Admin, new List<Permission> {Permission.ManageUsers, Permission.AddBook, Permission.RemoveBook, Permission.EditBook, Permission.ShowBooks} },
                        { Role.Worker, new List<Permission> {Permission.AddBook, Permission.RemoveBook, Permission.EditBook, Permission.ShowBooks} },
                        { Role.Client, new List<Permission> {Permission.ShowBooks, Permission.BuyBook} },
                    };
        }

        //Metoda, sprawdzająca Czy rola danej osoby ma dane pozwolenie
        public bool HasPermission(Osoba user, Permission permission)
        {
            if (_rolePermissions.ContainsKey(user.Roles) && _rolePermissions[user.Roles].Contains(permission))
            {
                return true;
            }
            return false;
        }
    }
}
