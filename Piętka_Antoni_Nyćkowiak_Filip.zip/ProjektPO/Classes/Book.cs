﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjektPO.Interfaces;
using System.Text.RegularExpressions; //Regex, Do sprawdzania czy string jest dobry  
using static KsiegarniaApp.Program;

namespace ProjektPO.Classes
{
    internal class Book : IInfo
    {
        //prywatne pola klasy Book
        private string _title;
        private string _author;
        private double _cena;
        private int _ilosc;

        //właściwości klasy Book
        public string Tytul //tytuł książki
        {
            get { return _title; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Wartość nie może być pusta");
                _title = value;
            }
        }
        public string Autor //autor książki
        {
            get { return _author; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Wartość nie może być pusta");
                _author = value;
            }
        }
        public double Cena  //cena książki
        {
            get { return _cena; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException("Cena nie może być mniejsza lub równa 0");
                _cena = value;
            }
        }
        public int Ilosc    //Ilość książki na stanie
        {
            get { return _ilosc; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Ilość książek nie może być mniejsza od 0");
                _ilosc = value;
            }
        }

        //konstruktory
        public Book() { }
        public Book(string tytul, string autor, double cena, int ilosc)
        {
            Tytul = tytul;
            Autor = autor;
            Cena = cena;
            Ilosc = ilosc;
        }
        //metoda wyświetlająca informacje o książce
        public string DisplayInfo()
        {
            return ($"\n\"{Tytul}\" {Autor}, kosztuje: {Cena}");
        }
    }
}
