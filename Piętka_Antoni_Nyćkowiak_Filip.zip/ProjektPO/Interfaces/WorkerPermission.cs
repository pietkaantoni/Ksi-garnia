﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektPO.Interfaces
{
    //interface mający metody dla pracownika
    internal interface WorkerPermission
    {
        void AddBook();
        void RemoveBook();
        void EditBook();
    }
}
