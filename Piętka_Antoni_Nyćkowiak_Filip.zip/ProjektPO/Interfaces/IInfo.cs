﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektPO.Interfaces
{
    //interface mający metodę pokazania informacji
    internal interface IInfo
    {
        string DisplayInfo();
    }
}
