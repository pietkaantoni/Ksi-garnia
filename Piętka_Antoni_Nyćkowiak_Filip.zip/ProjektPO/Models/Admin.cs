﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjektPO.Classes;
using ProjektPO.Interfaces;
using static KsiegarniaApp.Program;

namespace ProjektPO.Models
{
    internal class Admin : Worker, AdminPermission
    {
        public Admin(string username) : base(username)
        {
            Roles = Enums.Role.Admin;   //Przypisywanie roli adminowi
        }

        public void ManageUsers()
        {
            OnPowiadomienie($"{this.Username} zarądził urzytkownikami");
            //dokończyć
        }
    }
}
