﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjektPO.Classes;
using ProjektPO.Interfaces;
using static KsiegarniaApp.Program;

namespace ProjektPO.Models
{
    internal class Client : Osoba, ClientPermission
    {
        public List<Book> BoughtBooks { get; set; } = new List<Book>();
        
        public Client(string username) : base(username)
        {
            Roles = Enums.Role.Client;
        }

        //Metoda, pokazujące kupione książki przez użytkownika w trakcie danego wejścia do programu, taki koszyk zakupów
        public void ShowBoughtBooks()
        {
            Console.WriteLine("\nHistoria kupowania:");
            foreach (var k in BoughtBooks)
            {
                Console.WriteLine($"\t - {k.DisplayInfo()}");
            }
        }

        //Metoda, kupijące książkę o podadnym tytule
        public void BuyBook()
        {
            Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
            Console.WriteLine("\nPodaj tytuł książki, w której chcecz coś zmienić: ");
            string title = Console.ReadLine();
            foreach (var book in Ksiegarnia.Instance.Books)
            {
                try
                {
                    if (book.Tytul.ToLower() == title.ToLower())
                    {
                        book.Ilosc = book.Ilosc - 1;
                        BoughtBooks.Add(book);
                        SaveLog($"Klient: {Username}  kupił książkę \"{title}\"");
                        OnPowiadomienie($"\nKupiono książkę \"{title}\"");
                        return;
                    }
                }
                catch (ArgumentException e)
                {
                    ChangeColor("Błąd: " + e.Message, ConsoleColor.Red);
                    return;
                }
            }
            ChangeColor($"\nBłąd: Nie ma książki o tytule \"{title}\"", ConsoleColor.Red);
        }
    }
}
