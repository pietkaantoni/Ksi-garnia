﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjektPO.Classes;
using ProjektPO.Interfaces;
using static KsiegarniaApp.Program;

namespace ProjektPO.Models
{
    internal class Worker : Osoba, WorkerPermission
    {
        public Worker(string username) : base(username)
        {
            Roles = Enums.Role.Worker;
        }

        //Metoda dodająca podaną liczbe jakiejś istniejącej już książki LUB dodanie nowej książki do księgarnii
        public void AddBook()
        {
            Console.WriteLine($"\nWybierz kolejną opcję:");
            Console.WriteLine($"\t1. Dokupić instniejącą książkę");
            Console.WriteLine($"\t2. Kupić nową książkę");
            int choice = GetIntInput(1,2);
            switch (choice)
            {
                case 1: //Dodaje więcej będących już w księgarnii książek
                    Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
                    Console.WriteLine("Podaj tytuł książki, którą chcecz dokupić: ");
                    //Pętla, umożliwia ciągłe pytanie o tytuł książki, aż użytkownik poda taki, który istnieje
                    while (true)
                    {
                        string title = Console.ReadLine();
                        foreach (var book in Ksiegarnia.Instance.Books)
                        {
                            if (book.Tytul.ToLower() == title.ToLower())
                            {
                                Console.WriteLine($"Podaj ile książek \"{book.Tytul}\" {book.Autor} chcesz dokupić: ");
                                int howMany = GetIntInput(0, 1024);
                                book.Ilosc += howMany;
                                SaveLog($"Pracownik: {Username}  dokupił {howMany} książek \"{book.Tytul}\"");
                                OnPowiadomienie($"Dodano {howMany} książkek \"{book.Tytul}\"");
                                return;
                            }
                        }
                        ChangeColor($"\nNie ma książki o tytule \"{title}\"", ConsoleColor.Red);
                        Console.WriteLine("\nWybierz jednen z DOSTĘPNYCH tytułów:");
                    }
                case 2: //Dodaje nową książkę do księgarnii
                    Book newbook = new Book();
                    while (true)
                    {
                        try
                        {
                            Console.WriteLine("\nPodaj tytuł książki, którą chcecz kupić: ");
                            newbook.Tytul = Console.ReadLine();
                            foreach(Book book in Ksiegarnia.Instance.Books)
                            {
                                if (newbook.Tytul.ToLower() == book.Tytul.ToLower())
                                    throw new ArgumentException("Już taka książka znajduje się w bibiotece");
                            }
                            Console.WriteLine("\nPodaj autora książki, którą chcecz kupić: ");
                            newbook.Autor = Console.ReadLine();
                            Console.WriteLine("\nPodaj cenę książki, którą chcecz kupić: ");
                            double.TryParse(Console.ReadLine(), out double cena);
                            newbook.Cena = cena;
                            Console.WriteLine($"\nPodaj ile książek o tytule {newbook.Tytul}, chcecz kupić: ");
                            newbook.Ilosc = int.Parse(Console.ReadLine());
                            Ksiegarnia.Instance.Books.Add(newbook);
                            SaveLog($"Pracownik: {Username}  kupił {newbook.Ilosc} książek \"{newbook.Tytul}\"");
                            OnPowiadomienie($"Dodano {newbook.Ilosc} książkek \"{newbook.Tytul}\" {newbook.Autor} w cenie {newbook.Cena}");
                            return;
                        }
                        catch (ArgumentException e)
                        {
                            ChangeColor("Błąd: " + e.Message, ConsoleColor.Red);
                            ChangeColor("\nSpróbuj dodać książkę od początku:", ConsoleColor.Gray);
                        }
                        catch (Exception e)
                        {
                            ChangeColor("Błąd: " + e.Message, ConsoleColor.Red);
                            ChangeColor("\nSpróbuj dodać książkę od początku:", ConsoleColor.Gray);
                        }
                    }
                default:
                    return;
            }
        }
        //Metoda usuwające wszystkie książki z księgarnii o danym tytule
        public void RemoveBook()
        {
            Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
            Console.WriteLine("Podaj tytuł książki, którą chcecz usunąć: ");
            while (true)
            {
                string title = Console.ReadLine();
                foreach (var book in Ksiegarnia.Instance.Books)
                {
                    if (book.Tytul.ToLower() == title.ToLower())
                    {
                        OnPowiadomienie($"{this.Username} usuniął książkę \"{book.Tytul}\" z księgarnii");
                        SaveLog($"Pracownik: {Username}  usunął książkę \"{book.Tytul}\" z księgarnii");
                        Ksiegarnia.Instance.Books.Remove(book);
                        return;
                    }
                }
                ChangeColor($"\nNie ma książki o tytule \"{title}\"", ConsoleColor.Red);
                Console.WriteLine("\nWybierz jednen z DOSTĘPNYCH tytułów:");
            }
        }
        //Metoda, modyfikujące ksążki, będące już w księgarnii
        public void EditBook()
        {
            Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
            Console.WriteLine("\nPodaj tytuł książki, w której chcecz coś zmienić: ");
            while (true)
            {
                string title = Console.ReadLine();
                foreach (var book in Ksiegarnia.Instance.Books)
                {
                    try
                    {
                        if (book.Tytul.ToLower() == title.ToLower())
                        {
                            Console.WriteLine($"\nPodaj co chcesz zmienić w tej książce: ");
                            Console.WriteLine($"\t1. Tytuł ");
                            Console.WriteLine($"\t2. Autora ");
                            Console.WriteLine($"\t3. Cenę ");
                            int choice = GetIntInput(1, 3);
                            switch (choice)
                            {
                                //zmiana tytułu książki
                                case 1: 
                                    Console.WriteLine($"\nObecny tytuł: {book.Tytul}\nPodaj na jaki tytuł chcesz go zmienić:");
                                    while (true) 
                                    { 
                                        string title2 = Console.ReadLine();
                                        try
                                        {
                                            book.Tytul = title2;
                                            OnPowiadomienie($"\nZmieniono tytuł książki \"{title}\" na \"{title2}\"");
                                            return;
                                        }
                                        catch (ArgumentException e)
                                        {
                                            ChangeColor("Błąd: "+e.Message, ConsoleColor.Red);
                                            Console.WriteLine("\nPodaj tytuł książki jeszcze raz:");
                                        }
                                    }
                                //zmiana autora książki
                                case 2:
                                    Console.WriteLine($"\nObecny autor: {book.Autor}\nPodaj na jakiego autora chcesz go zmienić:");
                                    while (true)
                                    {
                                        string autor = Console.ReadLine();
                                        try
                                        {
                                            string oldAutor = book.Autor;
                                            book.Autor = autor;
                                            OnPowiadomienie($"\nZmieniono autora książki \"{title}\" z {oldAutor} na {autor}");
                                            return;
                                        }
                                        catch (ArgumentException e)
                                        {
                                            ChangeColor("Błąd: " + e.Message, ConsoleColor.Red);
                                            Console.WriteLine("\nPodaj autora książki jeszcze raz:");
                                        }
                                    }
                                //zmiana ceny książki
                                case 3:
                                    while (true)
                                    {
                                        Console.WriteLine($"\nObecna cena: {book.Cena:C}\nPodaj na jaką cenę chcesz ją zmienić:");
                                        double cena;
                                        try
                                        {
                                            double.TryParse(Console.ReadLine(), out cena);
                                            double oldCena = book.Cena;
                                            book.Cena = cena;
                                            OnPowiadomienie($"\nZmieniono cenę książki \"{title}\" z {oldCena:C} na {cena:C}");
                                            return;
                                        }
                                        catch (ArgumentException e)
                                        {
                                            ChangeColor("Błąd: " + e.Message, ConsoleColor.Red);
                                            Console.WriteLine("\nPodaj cenę książki jeszcze raz:");
                                        }
                                    }
                                default:
                                    break;
                            }
                        }
                    }
                    catch (ArgumentException e)
                    {
                        ChangeColor("Błąd: " + e.Message, ConsoleColor.Red);
                        break;
                    }
                }
                ChangeColor($"\nNie ma książki o tytule \"{title}\"", ConsoleColor.Red);
                Console.WriteLine("\nWybierz jednen z DOSTĘPNYCH tytułów:");
            }
        }
    }
}
