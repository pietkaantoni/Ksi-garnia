﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using static KsiegarniaApp.Program;
using ProjektPO.Classes;
using ProjektPO.Enums;
using ProjektPO.Models;
using System.Data;
using System.Security;

namespace KsiegarniaApp
{
    public class Program
    {
        //funkcja zmieniająca kolor kawałku tekstu, przyspiesza, skraca pisanie kodu oraz sprawia że wygląd aplikacji jest czytelniejszy
        public static void ChangeColor(string message, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ForegroundColor = ConsoleColor.White;
        }

        //funkcja, automatycznie pobiera i zwraca liczbę całkowitą z podanego zakresu
        internal static int GetIntInput(int minInput, int maxInput)
        {
            int input = -1;
            while (input == -1)
            {
                try
                {
                    input = int.Parse(Console.ReadLine());
                    if (input < 0)
                    {
                        input = -1;
                        throw new ArgumentException("Wybór musi być liczbą naturalną");
                    }
                    if (input < minInput || input > maxInput)
                    {
                        input = -1;
                        throw new ArgumentOutOfRangeException($"Wybór musi być z zakresu: <{minInput}; {maxInput}>");
                    }
                }
                catch (ArgumentNullException)
                {
                    ChangeColor($"Błąd: Wybór nie może być pusty \nSpróbój jeszcze raz. ", ConsoleColor.Red);
                    Console.WriteLine("\nWybierz jedną z DOSTĘPNYCH opcji:");
                }
                catch (ArgumentOutOfRangeException e)
                {
                    ChangeColor($"Błąd: {e.Message} \nSpróbój jeszcze raz. ", ConsoleColor.Red);
                    Console.WriteLine("\nWybierz jedną z DOSTĘPNYCH opcji:");
                }
                catch (ArgumentException e)
                {
                    ChangeColor($"Błąd: {e.Message} \nSpróbój jeszcze raz. ", ConsoleColor.Red);
                    Console.WriteLine("\nWybierz jedną z DOSTĘPNYCH opcji:");
                }
                catch (FormatException)
                {
                    ChangeColor($"Błąd: Wybór musi być liczbą całkowitą \nSpróbój jeszcze raz. ", ConsoleColor.Red);
                    Console.WriteLine("\nWybierz jedną z DOSTĘPNYCH opcji:");
                }
                catch (Exception e)
                {
                    ChangeColor($"Błąd: {e.Message} \nSpróbój jeszcze raz. ", ConsoleColor.Red);
                    Console.WriteLine("\nWybierz jedną z DOSTĘPNYCH opcji:");
                }
            }
            return input;
        }

        //funkcja, zapisująca logi w pliku zewnętrznym
        internal static void SaveLog(string message)
        {
            if (!File.Exists("logs.txt"))
            {
                File.Create("logs.txt").Dispose();
            }
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] - {message}";
            File.AppendAllText("logs.txt", logEntry);
        }
        internal static void OnPowiadomienieReceived(object sender, string message)
        {
            Console.WriteLine($"Powiadomienie: {message}");
        }

        //funkcja, inicjalizująca logowanie użytkownika oraz, przekierowująca do odpowiedniego Menu
        internal static void Login() 
        {
            //zczytywanie użytkowników z pliku zewnętrznego
            Uzytkownicy.Clear();
            foreach (var line in File.ReadLines("userPasswords.txt"))
            {
                var parts = line.Split(',');
                Osoba os = new Osoba(parts[0]);
                switch (parts[2])
                {
                    case "admin":
                        os.Roles = Role.Admin;
                        break;
                    case "worker":
                        os.Roles = Role.Worker;
                        break;
                    case "client":
                        os.Roles = Role.Client;
                        break;
                }
                
                Uzytkownicy.Add(os.Username, os);
                Uzytkownicy[os.Username].Powiadomienie += OnPowiadomienieReceived;
            }

            //Pobieranie informacji do logowania
            Console.WriteLine("Wprowadź nazwę użytkownika: ");
            string username = Console.ReadLine();

            Console.WriteLine("Wprowadź hasło: ");
            string password = Console.ReadLine();

            //Sprawdzenie czy istnieje taki użytkownik z podanym hasłem
            if (!PasswordManager.VerifyPassword(username, password))
            {
                ChangeColor("Niepopeawna nazwa użytkownika lub hasło", ConsoleColor.Red);
                ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                Console.ReadKey();
            }
            else
            {
                ChangeColor("\nLogowanie powiodło się", ConsoleColor.Green);
                ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                Console.ReadKey();

                //Przekierowanie do odpowiedniego Menu względem roli, jaką posiada
                if (Uzytkownicy[username].Roles == Role.Admin)
                {
                    var osoba = new Admin(Uzytkownicy[username].Username);
                    SaveLog($"Admin: {osoba.Username} zalogował się");
                    AdminMenu(osoba);
                }
                else if (Uzytkownicy[username].Roles == Role.Worker)
                {
                    var osoba = new Worker(Uzytkownicy[username].Username);
                    SaveLog($"Pracownik: {osoba.Username} zalogował się");
                    WorkerMenu(osoba);
                }
                else if (Uzytkownicy[username].Roles == Role.Client)
                {
                    var osoba = new Client(Uzytkownicy[username].Username);
                    SaveLog($"Klient: {osoba.Username}  zalogował się");
                    ClientMenu(osoba);
                }
            }
        }

        //funkcja, rejestrująca użytkownika i zapisująca go do pliku zewnętrznego
        public static void Rejestracja() 
        {
            Console.Write("\nPodaj nazwę użytkownika: ");
            string imie = Console.ReadLine();

            if (string.IsNullOrEmpty(imie))
            {
                ChangeColor("Imię nie może być puste.", ConsoleColor.Red);
                return;
            }
            Osoba osoba = new Osoba(imie);

            Console.WriteLine("Podaj hasło:");
            osoba.Powiadomienie += OnPowiadomienieReceived; //subskrybcja zdarzenia przy rejestracji
            string newPassword = Console.ReadLine();

            Console.WriteLine("\nDostępne role:");
            Console.WriteLine("\t1. Admin");
            Console.WriteLine("\t2. Praconik");
            Console.WriteLine("\t3. Klient");

            switch (GetIntInput(1, 3))
            {
                case 1:
                    PasswordManager.SavePassword(imie, newPassword, "admin");
                    break;
                case 2:
                    PasswordManager.SavePassword(imie, newPassword, "worker");
                    break;
                case 3:
                    PasswordManager.SavePassword(imie, newPassword, "client");
                    break;
                default:
                    return;
            }
            SaveLog($"Użytkownik: {osoba.Username}  zarejestrował się");
        }

        //Menu, pokazywane klientowi
        internal static void ClientMenu(Client osoba)
        {
            RBAC rbac = new RBAC();
            bool running = true;
            while (running)
            {
                Console.Clear();
                ChangeColor($"==Witamy {osoba.Username} w systemie Menu dla klieta Księgarni==", ConsoleColor.DarkGray);
                Console.WriteLine("Twoje opcje:");
                Console.WriteLine("\t1. Pokaż książki w księgarnii");
                Console.WriteLine("\t2. Kup książkę");
                Console.WriteLine("\t3. Historia kupowania");
                Console.WriteLine("\t0. Wyloguj się\n");
                int choice = GetIntInput(0,3);
                switch (choice)
                {
                    case 1:
                        Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
                        SaveLog($"Użytkownik: {osoba.Username}  wyświetliła zawartość księgarnii");
                        break;
                    case 2:
                        osoba.BuyBook();
                        break;
                    case 3:
                        osoba.ShowBoughtBooks();
                        break;
                    case 0:
                        running = false;
                        ChangeColor("\nZostałeś wylogowany\n", ConsoleColor.Gray);
                        break;
                    default:
                        break;
                }
                ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                Console.ReadKey();
            }
        }

        //Menu, dla pracownika
        internal static void WorkerMenu(Worker osoba)
        {
            RBAC rbac = new RBAC();
            bool running = true;
            while (running)
            {
                Console.Clear();
                ChangeColor($"==Witamy {osoba.Username} w systemie Menu dla pracownika Księgarni==", ConsoleColor.DarkGray);
                Console.WriteLine("Twoje opcje:");
                Console.WriteLine("\t1. Pokaż książki w księgarnii");
                Console.WriteLine("\t2. Dodaj książkę");
                Console.WriteLine("\t3. Usuń książkę");
                Console.WriteLine("\t4. Edytuj książkę");
                Console.WriteLine("\t0. Wyloguj się\n");
                int choice = GetIntInput(0,4);
                switch (choice)
                {
                    case 1:
                        Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
                        break;
                    case 2:
                        osoba.AddBook();
                        break;
                    case 3:
                        osoba.RemoveBook();
                        break;
                    case 4:
                        osoba.EditBook();
                        break;
                    case 0:
                        running = false;
                        ChangeColor("\nZostałeś wylogowany\n", ConsoleColor.Gray);
                        break;
                    default:
                        break;
                }
                ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                Console.ReadKey();
            }
        }

        //Menu dla Adminów
        internal static void AdminMenu(Admin osoba)
        {
            RBAC rbac = new RBAC();
            bool running = true;
            while (running)
            {
                Console.Clear();
                ChangeColor($"==Witamy {osoba.Username} w systemie Menu dla admina Księgarni==", ConsoleColor.DarkGray);
                Console.WriteLine("Twoje opcje:");
                Console.WriteLine("\t1. Pokaż książki w księgarnii");
                Console.WriteLine("\t2. Dodaj książkę");
                Console.WriteLine("\t3. Usuń książkę");
                Console.WriteLine("\t4. Edytuj książkę");
                Console.WriteLine("\t5. Zarządzaj użytkownikami (Niedostępne)");
                Console.WriteLine("\t0. Wyloguj się\n");
                int choice = GetIntInput(0,5);
                switch (choice)
                {
                    case 1:
                        Console.WriteLine(Ksiegarnia.Instance.DisplayInfo());
                        break;
                    case 2:
                        osoba.AddBook();
                        break;
                    case 3:
                        osoba.RemoveBook();
                        break;
                    case 4:
                        osoba.EditBook();
                        break;
                    case 5:
                        osoba.ManageUsers();
                        break;
                    case 0:
                        running = false;
                        ChangeColor("\nZostałeś wylogowany\n", ConsoleColor.Gray);
                        break;
                    default:
                        break;
                }
                ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                Console.ReadKey();
            }
        }

        //słownik z użytkownikami
        static Dictionary<string, Osoba> Uzytkownicy = new Dictionary<string, Osoba>();
        static void Main()
        {
            //zapisywanie kilku przykładowych użytkowników na plik zewnętrzny
            PasswordManager.SavePassword("AdminUser", "adminPassword", "admin");
            PasswordManager.SavePassword("WorkerUser", "workerPassword", "worker");
            PasswordManager.SavePassword("NormalUser", "userPassword", "client");

            //Pętla dotycząca logowania w księgarnii
            while (true)
            {
                Console.Clear();
                ChangeColor("==Witamy w systemie Logowania Księgarni==", ConsoleColor.DarkGray);
                Console.WriteLine("Proszę wybrać jedną z opcji:");
                Console.WriteLine("\t0. Wyjdź z programu");
                Console.WriteLine("\t1. Zaloguj się");
                Console.WriteLine("\t2. Zarejestruj się\n");
                int input = GetIntInput(0,2);
                switch (input)
                {
                    case 0:
                        Console.WriteLine("\nDziękujemy za skorzysanie z naszego programu");
                        Task.Delay(1000).Wait();    //Sprawia, że konsola czeka 1000 milisekund
                        return;
                    case 1:
                        Login();
                        break;
                    case 2:
                        Rejestracja();
                        ChangeColor("\nRejestracja powiodła się", ConsoleColor.Green);
                        ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                        Console.ReadKey();
                        break;
                    default:
                        ChangeColor("--Kliknij, aby kontynuować działanie programu--", ConsoleColor.DarkGray);
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
