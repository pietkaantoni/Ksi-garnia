﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektPO.Enums
{
    //zbiór wszystkich ról w programie
    internal enum Role
    {
        Admin,
        Worker,
        Client
    }
}
