﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektPO.Enums
{
    //zbiór wszystkich pozwoleń w programie
    internal enum Permission
    {
        ManageUsers,
        AddBook,
        RemoveBook,
        EditBook,
        ShowBooks,
        BuyBook,
    }
}
